
#include <iostream>
#include <string>
#include <limits>
#include <fstream>
using namespace std;
void clearInput()
{
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}
int readInt(const string& prompt)
{
    int x;
    while (true)
    {
        cout << prompt;
        if (cin >> x) { clearInput(); return x; }
        cout << "Invalid number. Please try again.\n";
        clearInput();
    }
}
float readFloat(const string& prompt)
{
    float x;
    while (true)
    {
        cout << prompt;
        if (cin >> x) { clearInput(); return x; }
        cout << "Invalid number. Please try again.\n";
        clearInput();
    }
}
string readLine(const string& prompt)
{
    cout << prompt;
    string s;
    getline(cin, s);
    return s;
}
struct Student
{
    int id = 0;
    string name;
    float marks = 0.0f;
};
struct StudentNode
{
    Student data;
    StudentNode* next = nullptr;

    StudentNode(const Student& s) : data(s), next(nullptr) {}
};
class StudentLinkedList
{
private:
    StudentNode* head = nullptr;

public:
    ~StudentLinkedList()
    {
        StudentNode* cur = head;
        while (cur)
        {
            StudentNode* nxt = cur->next;
            delete cur;
            cur = nxt;
        }
        head = nullptr;
    }
    StudentNode* getHead() const { return head; }
    void insertFront(const Student& s)
    {
        StudentNode* node = new StudentNode(s);
        node->next = head;
        head = node;
    }
    bool deleteById(int id, Student& deletedOut)
    {
        StudentNode* cur = head;
        StudentNode* prev = nullptr;
        while (cur)
        {
            if (cur->data.id == id)
            {
                deletedOut = cur->data;

                if (prev) prev->next = cur->next;
                else head = cur->next;

                delete cur;
                return true;
            }
            prev = cur;
            cur = cur->next;
        }
        return false;
    }
    void displayAll() const
    {
        if (!head)
        {
            cout << "No student records found.\n";
            return;
        }
        cout << "\n--- Student Records ---\n";
        cout << "ID\tName\t\tMarks\n";
        cout << "----------------------------\n";
        StudentNode* cur = head;
        while (cur)
        {
            cout << cur->data.id << "\t" << cur->data.name << "\t\t" << cur->data.marks << "\n";
            cur = cur->next;
        }
        cout << "----------------------------\n";
    }
};
struct BSTNode
{
    int keyId = 0;
    StudentNode* ref = nullptr;
    BSTNode* left = nullptr;
    BSTNode* right = nullptr;

    BSTNode(int id, StudentNode* r) : keyId(id), ref(r) {}
};
class StudentBST
{
private:
    BSTNode* root = nullptr;

    BSTNode* insertRec(BSTNode* node, int id, StudentNode* ref)
    {
        if (!node) return new BSTNode(id, ref);

        if (id < node->keyId) node->left = insertRec(node->left, id, ref);
        else if (id > node->keyId) node->right = insertRec(node->right, id, ref);
        else node->ref = ref; // update ref if already exists
        return node;
    }
    BSTNode* searchRec(BSTNode* node, int id) const
    {
        if (!node) return nullptr;
        if (id == node->keyId) return node;
        if (id < node->keyId) return searchRec(node->left, id);
        return searchRec(node->right, id);
    }
    BSTNode* findMin(BSTNode* node) const
    {
        while (node && node->left) node = node->left;
        return node;
    }
    BSTNode* deleteRec(BSTNode* node, int id)
    {
        if (!node) return nullptr;
        if (id < node->keyId) node->left = deleteRec(node->left, id);
        else if (id > node->keyId) node->right = deleteRec(node->right, id);
        else
        {
            if (!node->left)
            {
                BSTNode* r = node->right;
                delete node;
                return r;
            }
            if (!node->right)
            {
                BSTNode* l = node->left;
                delete node;
                return l;
            }
            BSTNode* succ = findMin(node->right);
            node->keyId = succ->keyId;
            node->ref = succ->ref;
            node->right = deleteRec(node->right, succ->keyId);
        }
        return node;
    }
    void destroy(BSTNode* node)
    {
        if (!node) return;
        destroy(node->left);
        destroy(node->right);
        delete node;
    }
public:
    ~StudentBST()
    {
        destroy(root);
        root = nullptr;
    }
    void insert(int id, StudentNode* ref)
    {
        root = insertRec(root, id, ref);
    }
    StudentNode* search(int id) const
    {
        BSTNode* n = searchRec(root, id);
        return n ? n->ref : nullptr;
    }
    void rebuildFromList(StudentNode* head)
    {
        destroy(root);
        root = nullptr;
        StudentNode* cur = head;
        while (cur)
        {
            insert(cur->data.id, cur);
            cur = cur->next;
        }
    }
};
enum class ActionType { ADD, UPDATE, DELETE };
struct Action
{
    ActionType type;
    Student before; 
    Student after;
};
struct ActionNode
{
    Action data;
    ActionNode* next = nullptr;
    ActionNode(const Action& a) : data(a), next(nullptr) {}
};
class ActionStack
{
private:
    ActionNode* top = nullptr;
public:
    ~ActionStack()
    {
        while (top)
        {
            ActionNode* t = top;
            top = top->next;
            delete t;
        }
    }
    void push(const Action& a)
    {
        ActionNode* n = new ActionNode(a);
        n->next = top;
        top = n;
    }
    bool pop(Action& out)
    {
        if (!top) return false;
        out = top->data;
        ActionNode* t = top;
        top = top->next;
        delete t;
        return true;
    }
    bool isEmpty() const { return top == nullptr; }
};
struct ReqNode
{
    string msg;
    ReqNode* next = nullptr;
    ReqNode(const string& m) : msg(m), next(nullptr) {}
};
class RequestQueue
{
private:
    ReqNode* front = nullptr;
    ReqNode* rear = nullptr;
public:
    ~RequestQueue()
    {
        while (front)
        {
            ReqNode* t = front;
            front = front->next;
            delete t;
        }
        rear = nullptr;
    }
    void enqueue(const string& msg)
    {
        ReqNode* n = new ReqNode(msg);
        if (!rear)
        {
            front = rear = n;
            return;
        }
        rear->next = n;
        rear = n;
    }
    bool dequeue(string& out)
    {
        if (!front) return false;
        out = front->msg;
        ReqNode* t = front;
        front = front->next;
        if (!front) rear = nullptr;
        delete t;
        return true;
    }
    void display() const
    {
        if (!front)
        {
            cout << "No pending requests.\n";
            return;
        }
        cout << "\n--- Pending Requests (FIFO) ---\n";
        ReqNode* cur = front;
        int i = 1;
        while (cur)
        {
            cout << i++ << ". " << cur->msg << "\n";
            cur = cur->next;
        }
    }
};
class RecentActivityArray
{
private:
    static const int SIZE = 10;
    string items[SIZE];
    int idx = 0;
    int count = 0;
public:
    void add(const string& text)
    {
        items[idx] = text;
        idx = (idx + 1) % SIZE;
        if (count < SIZE) count++;
    }
    void show() const
    {
        if (count == 0)
        {
            cout << "No recent activity.\n";
            return;
        }
        cout << "\n--- Recent Activity (Array: last " << count << ") ---\n";
        int start = (idx - 1 + SIZE) % SIZE; // newest
        for (int i = 0; i < count; i++)
        {
            int pos = (start - i + SIZE) % SIZE;
            cout << (i + 1) << ". " << items[pos] << "\n";
        }
    }
};
bool saveToFile(const string& filename, StudentNode* head)
{
    ofstream out(filename);
    if (!out) return false;
    StudentNode* cur = head;
    while (cur)
    {
        out << cur->data.id << "," << cur->data.name << "," << cur->data.marks << "\n";
        cur = cur->next;
    }
    return true;
}
bool loadFromFile(const string& filename, StudentLinkedList& list, RecentActivityArray& activity)
{
    ifstream in(filename);
    if (!in) return false;
    const int MAX_LOAD = 200;
    Student buffer[MAX_LOAD];
    int n = 0;
    string line;
    while (getline(in, line))
    {
        if (line.empty()) continue;
        if (n >= MAX_LOAD) break;
        size_t p1 = line.find(',');
        size_t p2 = line.rfind(',');
        if (p1 == string::npos || p2 == string::npos || p1 == p2) continue;
        Student s;
        s.id = stoi(line.substr(0, p1));
        s.name = line.substr(p1 + 1, p2 - (p1 + 1));
        s.marks = stof(line.substr(p2 + 1));
        buffer[n++] = s;
    }
    for (int i = 0; i < n; i++)
        list.insertFront(buffer[i]);
    activity.add("Loaded " + to_string(n) + " records from file.");
    return true;
}
int main()
{
    StudentLinkedList records;
    StudentBST indexBST;
    ActionStack undoStack;
    RequestQueue requests;
    RecentActivityArray activity;
    while (true)
    {
        cout << "\n==============================\n";
        cout << " Student Record Management System\n";
        cout << "==============================\n";
        cout << "1. Add Student\n";
        cout << "2. View All Students\n";
        cout << "3. Search Student (BST)\n";
        cout << "4. Update Student\n";
        cout << "5. Delete Student\n";
        cout << "6. Undo Last Operation (Stack)\n";
        cout << "7. Add Service Request (Queue)\n";
        cout << "8. View Service Requests (Queue)\n";
        cout << "9. Process Next Request (Queue)\n";
        cout << "A. View Recent Activity (Array)\n";
        cout << "S. Save to File (Bonus)\n";
        cout << "L. Load from File (Bonus)\n";
        cout << "0. Exit\n";
        cout << "Select: ";
        char ch;
        cin >> ch;
        clearInput();
        if (ch == '0') break;
        switch (ch)
        {
        case '1': // Add
        {
            Student s;
            s.id = readInt("Enter Student ID: ");
            s.name = readLine("Enter Student Name: ");
            s.marks = readFloat("Enter Marks (0-100): ");
            if (indexBST.search(s.id) != nullptr)
            {
                cout << "A student with this ID already exists.\n";
                break;
            }
            records.insertFront(s);
            indexBST.insert(s.id, records.getHead());
            Action a;
            a.type = ActionType::ADD;
            a.after = s;
            undoStack.push(a);
            activity.add("Added student ID " + to_string(s.id));
            cout << "Student added successfully.\n";
            break;
        }
        case '2': // View
            records.displayAll();
            break;
        case '3': // Search (BST)
        {
            int id = readInt("Enter Student ID to search: ");
            StudentNode* node = indexBST.search(id);
            if (!node)
            {
                cout << "Student not found.\n";
                break;
            }
            cout << "Found: ID=" << node->data.id
                 << ", Name=" << node->data.name
                 << ", Marks=" << node->data.marks << "\n";
            activity.add("Searched student ID " + to_string(id));
            break;
        }
        case '4': // Update
        {
            int id = readInt("Enter Student ID to update: ");
            StudentNode* node = indexBST.search(id);
            if (!node)
            {
                cout << "Student not found.\n";
                break;
            }
            Student before = node->data;
            cout << "Current Name: " << node->data.name << "\n";
            cout << "Current Marks: " << node->data.marks << "\n";
            string newName = readLine("Enter new name (leave empty to keep same): ");
            if (!newName.empty()) node->data.name = newName;
            node->data.marks = readFloat("Enter new marks (0-100): ");
            Action a;
            a.type = ActionType::UPDATE;
            a.before = before;
            a.after = node->data;
            undoStack.push(a);
            activity.add("Updated student ID " + to_string(id));
            cout << "Record updated successfully.\n";
            break;
        }
        case '5':
        {
            int id = readInt("Enter Student ID to delete: ");
            StudentNode* node = indexBST.search(id);
            if (!node)
            {
                cout << "Student not found.\n";
                break;
            }
            Student deleted;
            if (!records.deleteById(id, deleted))
            {
                cout << "Delete failed (unexpected).\n";
                break;
            }
            indexBST.rebuildFromList(records.getHead());
            Action a;
            a.type = ActionType::DELETE;
            a.before = deleted;
            undoStack.push(a);
            activity.add("Deleted student ID " + to_string(id));
            cout << "Record deleted successfully.\n";
            break;
        }
        case '6': 
        {
            Action last;
            if (!undoStack.pop(last))
            {
                cout << "Nothing to undo.\n";
                break;
            }
            if (last.type == ActionType::ADD)
            {
                Student dummy;
                records.deleteById(last.after.id, dummy);
                indexBST.rebuildFromList(records.getHead());
                activity.add("Undo ADD (removed ID " + to_string(last.after.id) + ")");
                cout << "Undo successful (ADD reverted).\n";
            }
            else if (last.type == ActionType::DELETE)
            {
                records.insertFront(last.before);
                indexBST.insert(last.before.id, records.getHead());
                activity.add("Undo DELETE (restored ID " + to_string(last.before.id) + ")");
                cout << "Undo successful (DELETE reverted).\n";
            }
            else if (last.type == ActionType::UPDATE)
            {
                StudentNode* node = indexBST.search(last.after.id);
                if (node)
                {
                    node->data = last.before;
                    activity.add("Undo UPDATE (reverted ID " + to_string(last.before.id) + ")");
                    cout << "Undo successful (UPDATE reverted).\n";
                }
                else
                {
                    cout << "Undo failed: record missing.\n";
                }
            }
            break;
        }
        case '7': 
        {
            string req = readLine("Write request (e.g., Transcript, Recheck, ID Card): ");
            if (req.empty())
            {
                cout << "Request cannot be empty.\n";
                break;
            }
            requests.enqueue(req);
            activity.add("Added a service request");
            cout << "Request added to queue.\n";
            break;
        }
        case '8': 
            requests.display();
            break;

        case '9': 
        {
            string out;
            if (!requests.dequeue(out))
            {
                cout << "No requests to process.\n";
                break;
            }
            activity.add("Processed a request");
            cout << "Processed request: " << out << "\n";
            break;
        }
        case 'A':
        case 'a':
            activity.show();
            break;
        case 'S':
        case 's':
        {
            if (saveToFile("students.csv", records.getHead()))
            {
                activity.add("Saved records to students.csv");
                cout << "Saved successfully.\n";
            }
            else
            {
                cout << "Failed to save file.\n";
            }
            break;
        }
        case 'L':
        case 'l':
        {
            if (loadFromFile("students.csv", records, activity))
            {
                indexBST.rebuildFromList(records.getHead());
                cout << "Loaded successfully.\n";
            }
            else
            {
                cout << "No file found or load failed.\n";
            }
            break;
        }
        default:
            cout << "Invalid option.\n";
            break;
        }
    }
    cout << "Exiting... Good luck for your viva!\n";
    return 0;
}
